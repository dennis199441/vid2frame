# vid2img
Convert video into images

## Python version
Python 3.6.4

## Dependencies
  1. opencv-python
  2. numpy

## How to install
vid2img has been published on Python Package Index (PyPi). vid2img can be installed using the following command.
```
pip install vid2img
```